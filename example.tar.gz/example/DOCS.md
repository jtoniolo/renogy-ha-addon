# Home Assistant Add-on: Example add-on

## How to use

This add-on really does nothing. It is just an example.

When started it will print the configured message or "Hello world" in the log.

It will also print "All done!" in `/share/example_addon_output.txt` to show
simple example of the usage of `map` in addon config.
